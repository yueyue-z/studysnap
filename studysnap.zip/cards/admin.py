from django.contrib import admin
from .models import Card, CardSet

admin.site.register(Card)

admin.site.register(CardSet)
